"""
Author: Dennis Barger
Date:   2/19/22

Lambda function to read and parse receipt image.  The function
leverages the AWS textract services via boto2.  Specifically
the function uses the Analyze Expense API within the textract
service.

Parameters

event:
{
    "s3": {
        "source": {
            "bucket": "string",
            "key": "string"
        },
        "target": {
            "bucket": "string",
            "key": "string"
        }
    }
}
"""

import boto3
import json

textract = boto3.client('textract', region_name = 'us-east-1')
s3 = boto3.resource('s3')

def put_object(bucket, key, data):
    obj = s3.Object(bucket, key)

    response = obj.put(
        Body = (bytes(json.dumps(data).encode('UTF-8')))
    )

    return(response)


def parse_receipt(content):
    response = textract.analyze_expense(
        Document = {
            'S3Object': {
                'Bucket': content['s3']['source']['bucket'],
                'Name': content['s3']['source']['key']
            }
        }
    )
    return response


def lambda_handler(event, context):

    receipt_text = parse_receipt(event)

    response = put_object(
        bucket = event['s3']['target']['bucket'],
        key = event['s3']['target']['key'],
        data = receipt_text
    )
    return response

# if __name__ == "__main__":
#     context = {}

#     event = {
#         "s3": {
#             "source": {
#                 "bucket": "dbarger-receipts",
#                 "key": "image/receipt-image.jpg"
#             },
#             "target": {
#                 "bucket": "dbarger-receipts",
#                 "key": "json/receipt-image.json"
#             }
#         }
#     }

#     response = lambda_handler(event, context)
#     print(json.dumps(response, indent=4))